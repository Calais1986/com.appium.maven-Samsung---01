package utils;

public class Device_Capability {

        public String device_model;
        public String brand;
        public String os;
        public String os_version;
    }

